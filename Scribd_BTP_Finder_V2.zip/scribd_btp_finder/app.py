"""Launch with: streamlit run app.py"""
import csv
import io
import os
import time

import streamlit as st
from core import TOPICS, brave_web_search, candidate_from_result, connect, make_queries, rows, save_candidate, verify_book

st.set_page_config(page_title='Catalogue livres BTP · Scribd', page_icon='📚', layout='wide')
st.title('📚 Recherche de livres BTP sur Scribd')
st.caption('Livres / manuels / ouvrages techniques uniquement · 101 pages minimum · recherche par index Web, sans extraction automatisée du contenu Scribd')
st.info('Le nombre de pages récupéré depuis un moteur de recherche est indicatif. Les candidats ne rejoignent le catalogue final qu’après ta vérification sur Scribd. Téléchargement via le bouton officiel, si disponible.')

conn = connect()

with st.sidebar:
    st.subheader('Configuration')
    api_key = st.text_input('Clé Brave Search API', value=os.getenv('BRAVE_SEARCH_API_KEY', ''), type='password', help='La clé est transmise uniquement à Brave Search lors des requêtes. Elle n’est pas enregistrée dans le catalogue.')
    st.markdown('[Obtenir une clé Brave Search](https://api-dashboard.search.brave.com/)')
    selected = st.multiselect('Disciplines', options=list(TOPICS), default=list(TOPICS)[:5])
    languages = st.multiselect('Langues de recherche', ['fr', 'en'], default=['fr', 'en'])
    max_queries = st.number_input('Nombre maximum de recherches API', min_value=1, max_value=150, value=15, step=1)
    st.caption('Une recherche peut produire au plus 20 résultats ; de nombreux liens seront écartés ou nécessiteront une vérification.')

if st.button('Lancer la recherche', type='primary', disabled=not(bool(api_key) and bool(selected) and bool(languages))):
    queries = make_queries(selected, languages)[:max_queries]
    seen, errors, saved = set(), [], 0
    bar = st.progress(0)
    for i, (topic, lang, query) in enumerate(queries):
        try:
            results = brave_web_search(api_key, query, lang)
            for result in results:
                candidate = candidate_from_result(result, topic, lang, query)
                if candidate and candidate['id'] not in seen:
                    save_candidate(conn, candidate)
                    saved += 1
                    seen.add(candidate['id'])
        except RuntimeError as e:
            errors.append(f'{query} : {e}')
            if '429' in str(e):
                break
        bar.progress((i + 1) / max(1, len(queries)))
        time.sleep(0.15)
    st.success(f'{saved} candidats trouvés ou actualisés. {len(errors)} recherche(s) en erreur.')
    for e in errors[:5]:
        st.warning(e)

valid = rows(conn, verified=True)
pending = rows(conn, verified=False)
a, b, c = st.columns(3)
a.metric('Livres validés (>100 pages)', len(valid))
b.metric('À vérifier', len(pending))
c.metric('Candidats avec pagination estimée', sum(bool(r['pages'] and r['pages'] > 100) for r in pending))

tab_valid, tab_pending = st.tabs(['Catalogue validé', 'Candidats à contrôler'])

with tab_valid:
    st.subheader('Ouvrages vérifiés')
    if valid:
        st.dataframe([{'Titre': r['title'], 'Pages': r['pages'], 'Discipline': r['discipline'], 'Langue': r['language'], 'Lien Scribd': r['url']} for r in valid],
                     column_config={'Lien Scribd': st.column_config.LinkColumn('Lien Scribd')}, hide_index=True, use_container_width=True)
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=['titre', 'pages', 'discipline', 'langue', 'url'])
        writer.writeheader()
        for r in valid:
            writer.writerow({'titre': r['title'], 'pages': r['pages'], 'discipline': r['discipline'], 'langue': r['language'], 'url': r['url']})
        st.download_button('Exporter les livres validés (CSV)', output.getvalue().encode('utf-8-sig'), 'livres_btp_101_pages.csv', 'text/csv')
    else:
        st.write('Aucun ouvrage validé. Lance une recherche et vérifie les candidats dans le second onglet.')

with tab_pending:
    st.subheader('Résultats de recherche')
    st.caption('Le compteur trouvé dans le résumé Web peut être absent, erroné ou correspondre à un autre ouvrage. Ouvre la fiche Scribd avant de valider.')
    if not pending:
        st.write('Aucun candidat en attente.')
    else:
        st.dataframe([{'ID': r['id'], 'Titre': r['title'], 'Pages estimées': r['pages'], 'Discipline': r['discipline'], 'Confiance type': r['kind'], 'Lien': r['url']} for r in pending],
                     column_config={'Lien': st.column_config.LinkColumn('Voir sur Scribd')}, hide_index=True, use_container_width=True)
        by_id = {r['id']: r for r in pending}
        selected_id = st.selectbox('Document à valider', list(by_id), format_func=lambda k: f"{by_id[k]['title'][:85]} · {k}")
        book = by_id[selected_id]
        st.markdown(f"**Fiche Scribd :** {book['url']}")
        pages = st.number_input('Nombre de pages affiché sur Scribd', min_value=1, max_value=10000, value=int(book['pages'] or 101))
        is_book = st.checkbox("J'ai vérifié qu'il s'agit d'un livre / manuel / ouvrage technique complet")
        if st.button('Valider ce livre', disabled=not(is_book and pages > 100)):
            verify_book(conn, selected_id, pages, True)
            st.rerun()
        if st.button('Écarter ce document'):
            verify_book(conn, selected_id, pages, False)
            st.rerun()

st.divider()
st.caption('Le moteur n’accède jamais à Scribd : il cherche dans l’index public de Brave. Il ne télécharge aucun PDF, ne contourne aucune restriction et ne détermine pas la légalité d’un dépôt. Vérifie les droits avant de réutiliser les fichiers.')
