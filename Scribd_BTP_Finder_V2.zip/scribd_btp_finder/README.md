# Catalogue BTP — Scribd (prototype)

Ce prototype **recherche des fiches Scribd indexées par le moteur Brave**, sans se connecter ni faire de scraping sur Scribd. Il ne télécharge **aucun** contenu de Scribd.

## Fonctions

- 12 disciplines BTP : structure, géotechnique, architecture, BIM, CVC, électricité, plomberie, travaux publics, matériaux, énergie, incendie, management de chantier.
- Recherche en français et en anglais, via l’API publique de **Brave Search** (nécessite une clé personnelle et éventuellement un forfait).
- Élimine les documents signalés comme ayant 100 pages ou moins et les titres clairement non assimilables à des livres (rapports, mémoires, catalogues, etc.).
- Nombre de pages **estimé** depuis les extraits du moteur de recherche. Celui-ci peut être incomplet ou erroné : un résultat reste « À vérifier » jusqu’à validation manuelle sur la fiche Scribd.
- Catalogue local SQLite, sans mot de passe Scribd.
- Export CSV **uniquement des livres vérifiés**, d’au moins 101 pages.
- Liens pour accéder à chaque fiche et utiliser, le cas échéant, le bouton de téléchargement **officiel**.

## Démarrage sur Windows

Installer Python 3.11 ou supérieur, ouvrir PowerShell dans ce dossier, puis :

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

Dans le navigateur, coller sa clé API Brave Search, choisir disciplines et langues, puis cliquer sur **Lancer la recherche**. Dans **Candidats à contrôler**, ouvrir le lien Scribd et vérifier les pages. Une fois confirmé qu’il s’agit d’un livre avec plus de 100 pages, valider ; le livre passe dans **Catalogue validé**.

La clé ne doit pas être mise dans le code. On peut également la passer par la variable d’environnement `BRAVE_SEARCH_API_KEY`.

## Limites

- L’API Brave Search est un service externe, avec conditions et tarifs propres. 1 requête donne au maximum 20 résultats ; **1 000 livres vérifiés ne sont pas garantis**.
- Le chiffre de pages n’est pas systématiquement visible dans l’index, et les extraits peuvent citer d’autres ouvrages. La validation est indispensable.
- Une fiche trouvée n’implique pas que l’éditeur autorise le téléchargement ou toute réutilisation du document.
- Le téléchargement automatique / scraping massif depuis Scribd n’est **pas** implémenté, conformément aux restrictions de leur service.
- Ce prototype n’a pas été testé avec une clé Brave réelle : seuls les tests unitaires locaux sont fournis.

## Tests

```powershell
python -m unittest -v
```
