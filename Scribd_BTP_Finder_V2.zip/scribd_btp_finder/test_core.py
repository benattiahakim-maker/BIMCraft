import sqlite3
import unittest
from core import parse_pages, candidate_from_result, book_likelihood, connect, save_candidate, verify_book, rows, make_queries

class SearchTests(unittest.TestCase):
    def test_pages_valid(self):
        self.assertEqual(parse_pages('2K views 400 pages')[0], 400)
        self.assertEqual(parse_pages('675 vues 144 pages')[0], 144)
        self.assertEqual(parse_pages('26 pages. A short document')[0], 26)
        self.assertEqual(parse_pages('Chapter 1 first page 53 and author bibliography 1000 pages')[0], None)
        self.assertEqual(parse_pages('There are several cited books that span 661 pages')[0], None)

    def test_candidate_filter(self):
        r = {'url':'https://fr.scribd.com/document/12345/abc','title':'Manuel de géotechnique | PDF', 'description': '10K vues 212 pages'}
        item = candidate_from_result(r,'Géotechnique','fr','test')
        self.assertEqual(item['pages'],212)
        self.assertEqual(item['id'],'12345')
        r['description'] = '1K vues 100 pages'
        self.assertIsNone(candidate_from_result(r,'Géotechnique','fr','test'))
        r['description'] = '0 vues 500 pages'
        r['title'] = 'Rapport de géotechnique'
        self.assertIsNone(candidate_from_result(r,'Géotechnique','fr','test'))

    def test_foreign_url_rejected(self):
        r = {'url':'https://scribd.com.attacker.example/document/1234/fake','title':'Construction Handbook','description':'500 pages'}
        self.assertIsNone(candidate_from_result(r,'Structures','en','test'))

    def test_save_and_verify(self):
        conn = connect(':memory:')
        c = {'id':'1','title':'Manual building engineering','url':'https://www.scribd.com/document/1/book','discipline':'Structures','language':'en','pages':300,'evidence':'index_web_après_vues','kind':'probable','description':'desc','query':'q','found_at':'now'}
        save_candidate(conn,c)
        self.assertEqual(len(rows(conn,True)),0)
        verify_book(conn,'1',300,True)
        self.assertEqual(len(rows(conn,True)),1)
        c['pages']=201
        save_candidate(conn,c)
        self.assertEqual(rows(conn,True)[0]['pages'],300)

    def test_queries(self):
        self.assertEqual(len(make_queries(['Structures'],['fr','en'],2)),4)

if __name__ == '__main__':
    unittest.main()
