"""Discover BTP book candidates using Brave Search metadata only.

Never requests, scrapes, logs into, or downloads from Scribd.
"""
from __future__ import annotations

import html
import json
import re
import sqlite3
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

DB_PATH = Path(__file__).resolve().parent / 'catalogue.sqlite'

TOPICS = {
    'Structures': {'fr': ['béton armé', 'construction métallique', 'calcul des structures', 'Eurocode 2'], 'en': ['structural engineering', 'reinforced concrete', 'steel structures', 'structural design']},
    'Géotechnique': {'fr': ['géotechnique', 'mécanique des sols', 'fondations', 'Eurocode 7'], 'en': ['geotechnical engineering', 'soil mechanics', 'foundation engineering']},
    'Architecture': {'fr': ['conception architecturale', 'architecture bâtiment', 'détails constructifs'], 'en': ['building architecture', 'architectural construction', 'architectural detailing']},
    'BIM & numérique': {'fr': ['BIM bâtiment', 'Revit BIM', 'maquette numérique'], 'en': ['building information modeling', 'BIM construction', 'Revit BIM']},
    'CVC / HVAC': {'fr': ['chauffage ventilation climatisation', 'génie climatique', 'dimensionnement CVC'], 'en': ['HVAC design', 'heating ventilation air conditioning', 'air conditioning engineering']},
    'Électricité': {'fr': ['installations électriques bâtiment', 'électricité bâtiment', 'génie électrique bâtiment'], 'en': ['electrical building design', 'electrical installations buildings', 'electrical engineering handbook']},
    'Plomberie & hydraulique': {'fr': ['plomberie bâtiment', 'hydraulique bâtiment', 'assainissement'], 'en': ['plumbing engineering', 'water supply building', 'sanitary engineering']},
    'Routes & ouvrages d’art': {'fr': ['construction routière', 'ponts ouvrages art', 'génie civil tunnels'], 'en': ['highway engineering', 'bridge engineering', 'tunnel construction']},
    'Matériaux & méthodes': {'fr': ['matériaux de construction', 'techniques construction', 'construction bois'], 'en': ['construction materials', 'construction methods', 'timber engineering']},
    'Énergie & thermique': {'fr': ['thermique du bâtiment', 'performance énergétique bâtiment', 'isolation thermique'], 'en': ['building energy efficiency', 'building physics', 'thermal insulation building']},
    'Sécurité incendie': {'fr': ['sécurité incendie bâtiment', 'ingénierie sécurité incendie'], 'en': ['fire protection engineering', 'building fire safety']},
    'Management de chantier': {'fr': ['gestion de chantier', 'économie de la construction', 'conduite travaux'], 'en': ['construction management', 'construction estimating', 'construction project management']},
}

# Avoid documents that are not books, even when they are lengthy.
NOT_BOOK = re.compile(
    r'\b(?:catalogue|catalog|mémoire|memoire|thèse|these|thesis|dissertation|'
    r'rapport|report|fiche technique|datasheet|brochure|slides?|présentation|presentation|'
    r'cctp|cahier des charges|procès.verbal|proces.verbal|appel d.offres|'
    r'curriculum|cv|test banque|examen|devoir|compte.rendu)\b', re.IGNORECASE,
)
BOOK_HINT = re.compile(
    r'\b(?:livre|book|manuel|manual|handbook|textbook|guide|traité|traite|'
    r'édition|edition|cours complet|cours pratique|exercices corrigés|'
    r'construction|engineering|génie|genie|architecture|design|techniques|'
    r'mécanique|mecanique|fondations|structures|eurocode|revit|bim|plumbing|hvac)\b', re.IGNORECASE,
)
PAGE_PATTERN = re.compile(r'(?<!\d)(\d{2,4})\s*(?:pages?|páginas?|paginas?|seiten|страниц|页)\b', re.IGNORECASE)
VIEW_PATTERN = re.compile(
    r'(?:\d[\d\s.,]*[KkMm]?\s*(?:vues?|views?|visualizaciones|aufrufe)\s+)'
    r'(\d{2,4})\s*(?:pages?|páginas?|paginas?|seiten|страниц|页)\b', re.IGNORECASE,
)
DOC_PATH = re.compile(r'^/document/(\d+)(?:/|$)', re.IGNORECASE)


def normalize(s: str) -> str:
    s = unicodedata.normalize('NFKD', s)
    return ''.join(c for c in s if not unicodedata.combining(c)).casefold()


def strip_markup(s: str) -> str:
    return re.sub(r'<[^>]+>', ' ', html.unescape(s or '')).strip()


def scribd_id(url: str) -> str | None:
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or '').lower()
        if host not in {'scribd.com', 'www.scribd.com', 'fr.scribd.com', 'es.scribd.com', 'de.scribd.com', 'pt.scribd.com'}:
            return None
        match = DOC_PATH.match(parsed.path)
        return match.group(1) if match else None
    except ValueError:
        return None


def parse_pages(snippet: str) -> tuple[int | None, str]:
    """Only read page totals from a search engine *summary*.

    Never inspect Scribd page text: bibliography page counts are misleading.
    A count after 'views/vues' is stronger evidence than a bare count.
    Everything found remains *unverified* until user confirms it on Scribd.
    """
    s = strip_markup(snippet)
    m = VIEW_PATTERN.search(s[:400])
    if m:
        return int(m.group(1)), 'index_web_après_vues'
    # A bare count is considered only if at the beginning of a snippet.
    m = PAGE_PATTERN.match(s)
    if m:
        return int(m.group(1)), 'index_web_non_confirmé'
    return None, 'inconnu'


def book_likelihood(title: str, desc: str) -> str:
    title = strip_markup(title)
    desc = strip_markup(desc)
    if NOT_BOOK.search(title):
        return 'exclu'
    if BOOK_HINT.search(title):
        return 'probable'
    if BOOK_HINT.search(desc[:200]):
        return 'à vérifier'
    return 'à vérifier'


def candidate_from_result(result: dict, topic: str, language: str, query: str) -> dict | None:
    url = result.get('url', '')
    doc_id = scribd_id(url)
    if not doc_id:
        return None
    title = strip_markup(result.get('title', '')).split(' | PDF')[0].strip()
    desc = strip_markup(result.get('description', ''))
    if not title or book_likelihood(title, desc) == 'exclu':
        return None
    pages, evidence = parse_pages(desc)
    # Extra snippets can quote entirely different documents / bibliographies.
    # Never use them to infer a page count.
    if pages is not None and pages <= 100:
        return None
    return {
        'id': doc_id, 'title': title, 'url': url, 'discipline': topic,
        'language': language, 'pages': pages, 'evidence': evidence,
        'kind': book_likelihood(title, desc), 'description': desc[:400],
        'query': query, 'found_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
    }


def make_queries(topics: list[str], langs: list[str], per_topic: int = 3) -> list[tuple[str, str, str]]:
    queries = []
    for category in topics:
        for lang in langs:
            words = TOPICS.get(category, {}).get(lang, [])
            for term in words[:per_topic]:
                queries.append((category, lang, f'site:scribd.com/document "{term}"'))
    return queries


def brave_web_search(key: str, query: str, lang: str, count: int = 20) -> list[dict]:
    params = urlencode({'q': query, 'count': min(count, 20), 'search_lang': lang, 'extra_snippets': 'false'})
    req = Request(
        'https://api.search.brave.com/res/v1/web/search?' + params,
        headers={'X-Subscription-Token': key, 'Accept': 'application/json', 'User-Agent': 'BTPBookFinder/0.1'},
    )
    try:
        with urlopen(req, timeout=25) as response:
            payload = json.load(response)
        return payload.get('web', {}).get('results', [])
    except HTTPError as e:
        # Do not expose key or response bodies in error messages.
        raise RuntimeError(f'Brave Search API : erreur HTTP {e.code} (vérifie la clé et les quotas).') from e
    except (URLError, TimeoutError) as e:
        raise RuntimeError('Connexion à Brave Search impossible.') from e


def connect(path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute('''CREATE TABLE IF NOT EXISTS books (
        id TEXT PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL,
        discipline TEXT NOT NULL, language TEXT NOT NULL,
        pages INTEGER, evidence TEXT NOT NULL, kind TEXT NOT NULL,
        description TEXT, query TEXT, found_at TEXT,
        verified INTEGER NOT NULL DEFAULT 0, rejected INTEGER NOT NULL DEFAULT 0
    )''')
    conn.commit()
    return conn


def save_candidate(conn: sqlite3.Connection, c: dict) -> None:
    conn.execute('''INSERT INTO books
        (id,title,url,discipline,language,pages,evidence,kind,description,query,found_at)
        VALUES (:id,:title,:url,:discipline,:language,:pages,:evidence,:kind,:description,:query,:found_at)
        ON CONFLICT(id) DO UPDATE SET
          pages=CASE WHEN books.verified=1 THEN books.pages
                     WHEN excluded.pages IS NOT NULL THEN excluded.pages
                     ELSE books.pages END,
          evidence=CASE WHEN books.verified=1 THEN books.evidence ELSE excluded.evidence END,
          description=excluded.description,
          query=excluded.query
    ''', c)
    conn.commit()


def verify_book(conn: sqlite3.Connection, doc_id: str, pages: int, is_book: bool) -> None:
    if is_book and pages > 100:
        conn.execute('UPDATE books SET pages=?, evidence=?, kind=?, verified=1, rejected=0 WHERE id=?',
                     (pages, 'vérifié_manuellement', 'livre', doc_id))
    else:
        conn.execute('UPDATE books SET rejected=1, verified=0 WHERE id=?', (doc_id,))
    conn.commit()


def rows(conn: sqlite3.Connection, verified: bool) -> list[dict]:
    if verified:
        cur = conn.execute('SELECT * FROM books WHERE verified=1 AND rejected=0 AND pages>100 ORDER BY discipline, title')
    else:
        cur = conn.execute('SELECT * FROM books WHERE verified=0 AND rejected=0 ORDER BY (pages IS NULL), pages DESC, title')
    return [dict(r) for r in cur.fetchall()]
